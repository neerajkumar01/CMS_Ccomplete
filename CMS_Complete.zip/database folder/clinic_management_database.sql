-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2021 at 03:12 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinic_management_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `consultation`
--

CREATE TABLE `consultation` (
  `CONSULTATIONID` int(1) NOT NULL,
  `CONSULTATIONFEE` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `consultation`
--

INSERT INTO `consultation` (`CONSULTATIONID`, `CONSULTATIONFEE`) VALUES
(1, 100);

-- --------------------------------------------------------

--
-- Table structure for table `dailyrecord`
--

CREATE TABLE `dailyrecord` (
  `DID` int(50) NOT NULL,
  `PNAME` varchar(225) NOT NULL,
  `PADDRESS` varchar(225) NOT NULL,
  `DATECAME` varchar(50) NOT NULL,
  `ENTRYTIME` date NOT NULL,
  `CURRENTAMOUNT` int(50) NOT NULL,
  `AMOUNTPAID` int(50) NOT NULL,
  `PID` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pdetails`
--

CREATE TABLE `pdetails` (
  `PID` int(225) NOT NULL,
  `PNAME` varchar(225) NOT NULL,
  `PADDRESS` varchar(225) NOT NULL,
  `ADHARID` varchar(12) NOT NULL,
  `AMOUNT` int(50) NOT NULL,
  `PHONENUMONE` varchar(10) NOT NULL,
  `PHONENUMTWO` varchar(10) NOT NULL,
  `ENTRYDATE` varchar(50) NOT NULL,
  `TIMEENTERED` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `registration_and_login`
--

CREATE TABLE `registration_and_login` (
  `REGISTRATIONID` int(50) NOT NULL,
  `USERNAME` varchar(225) NOT NULL,
  `PASSWORD` varchar(225) NOT NULL,
  `TYPE` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration_and_login`
--

INSERT INTO `registration_and_login` (`REGISTRATIONID`, `USERNAME`, `PASSWORD`, `TYPE`) VALUES
(15, 'admin1', 'e00cf25ad42683b3df678c61f42c6bda', 'admin'),
(16, 'normal', 'fea087517c26fadd409bd4b9dc642555', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dailyrecord`
--
ALTER TABLE `dailyrecord`
  ADD PRIMARY KEY (`DID`);

--
-- Indexes for table `pdetails`
--
ALTER TABLE `pdetails`
  ADD PRIMARY KEY (`PID`);

--
-- Indexes for table `registration_and_login`
--
ALTER TABLE `registration_and_login`
  ADD PRIMARY KEY (`REGISTRATIONID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dailyrecord`
--
ALTER TABLE `dailyrecord`
  MODIFY `DID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pdetails`
--
ALTER TABLE `pdetails`
  MODIFY `PID` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `registration_and_login`
--
ALTER TABLE `registration_and_login`
  MODIFY `REGISTRATIONID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
