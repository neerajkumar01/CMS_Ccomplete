<?php
  echo md5('neo');?>
<br>
  <?php
  echo md5('n');
?> 
  <br>
  <?php
  echo md5('e');
  ?>
  <br>
<?php
  echo md5('o');


?>